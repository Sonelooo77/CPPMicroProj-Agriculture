// Tests compatibility with iostream
#include <iostream>
#include "../src/pugixml.hpp"
