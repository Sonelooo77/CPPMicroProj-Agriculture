#include "../src/pugixml.hpp"

#if PUGIXML_VERSION != 1150 // 1.15
#error Unexpected pugixml version
#endif
